# Materialliste Geoelektrik 

- [ ] 4x Elektroden (= Metallstäbe)
- [ ] 2x Kabel "Bananenstecker", 20 m (weiss)
- [ ] 6x Kabel "Bananenstecker", 2 m
- [ ] 2x Multimeter analog
- [ ] 1x Multimeter digital
- [ ] 2x 12 V Batterie, voll geladen
- [ ] 2x Massband, 20 m
- [ ] 2x Heringe oder lange Nägel
- [ ] 1x Kiste um alles zu transportieren
